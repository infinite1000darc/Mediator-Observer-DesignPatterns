/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediator.ejemplo;

/**
 *
 * @author drdav
 */
public class Componente {
  protected Mediador m;
    // -------------------------------
    public Componente() {
    }
    // -------------------------------
     public Mediador getMediador()
    {
        return this.m;
    }
    // -------------------------------
     public void setMediador( Mediador m )
    {
        this.m = m;
    }
}
