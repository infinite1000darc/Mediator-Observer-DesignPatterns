/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediator.ejemplo;

/**
 *
 * @author drdav
 */
public class BotonBorrar extends Componente{
  public BotonBorrar() {
    }
    // -------------------------------
     public void clickBorrar()
    {
         this.getMediador().clickBorrar();
    }
}
