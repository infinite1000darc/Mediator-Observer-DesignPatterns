/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mediator.ejemplo;

/**
 *
 * @author drdav
 */
public class BotonAdios extends Componente{
  public BotonAdios() {
    }
    // -------------------------------
     public void clickAdios()
    {
         this.getMediador().clickAdios();
    }
}
